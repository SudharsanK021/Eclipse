package workingWithArrays;


public class RemoveDuplicatesFromArrays {

	public static int [] removeDuplicates() {

		int[] numbers = {1, 2, 2,2, 3, 4, 4, 5};
		int [] anotherArray = new int[numbers.length];

		System.out.println(numbers.length);


		int index = 0, count=0;

		for (int i = 0; i < numbers.length; i++) {
			for (int j = i+1; j < numbers.length; j++) {

				//System.out.println(i+"  "+j);

				if(numbers[i] != numbers[j]) {
					count = count + 1 ;
				}

			}

			System.out.println(count+ " "+((numbers.length)-(i+1)));

			if(count == ((numbers.length)-(i+1))) {
				anotherArray[index++] = numbers[i];
			}

			count = 0;

		}

		System.out.println("***********************");

		for (int i = 0; i < anotherArray.length; i++) {
			System.out.print(" "+anotherArray[i]);
		}

		return anotherArray;

	}

	public static void arrangeArray(int [] duplicatesFreeArr) {
		
		

		for (int i = 0; i < duplicatesFreeArr.length; i++) {
			for (int j = i; j < duplicatesFreeArr.length; j++) {
				
				
				if(duplicatesFreeArr[i] > duplicatesFreeArr[j]) {
					duplicatesFreeArr[i] = duplicatesFreeArr[i] + duplicatesFreeArr[j];
					duplicatesFreeArr[j] = duplicatesFreeArr[i] - duplicatesFreeArr[j];
					duplicatesFreeArr[i] = duplicatesFreeArr[i] - duplicatesFreeArr[j];
				}

			}
		}
		
		System.out.println("***********************");
		for (int i = 0; i < duplicatesFreeArr.length; i++) {
			System.out.print(" "+duplicatesFreeArr[i]);
		}



	}
	public static void main(String[] args) {
		
		RemoveDuplicatesFromArrays.arrangeArray(RemoveDuplicatesFromArrays.removeDuplicates());



	}

}
