package workingWithArrays;

public class twoDimensionalMatrixAddition {

	public static void main(String[] args) {
		int[][] matrixA = {
	            {1, 2},
	            {3, 4}
	        };
	        
	        int[][] matrixB = {
	            {5, 6},
	            {7, 8}
	        };
	        
	        
	        int [][] matrixC = new int[matrixA.length][matrixA[0].length];
	        
	        
	        for (int i = 0; i < matrixA.length; i++) {
				for (int j = 0; j < matrixA[i].length; j++) {
					
					matrixC[i][j]  = matrixA[i][j] + matrixB[i][j];
					
				}
			}
	        
	        for (int i = 0; i < 2; i++) {
	            for (int j = 0; j < 2; j++) {
	                System.out.print(matrixC[i][j] + " ");
	            }
	            System.out.println(); // Move to the next row
	        }

	}

}
