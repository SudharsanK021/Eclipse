package APIChaining_GoRest;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.*;

import java.util.HashMap;
import java.util.Map;

public class APIChainingDemo {
	
	
	private static String stringURI = "https://gorest.co.in/public/v2/users";
	private static int id = 0;
	private static String username = "Sudharsan";
	private static String email = "Sudharsan@testuser";
	private static String gender = "Male";
	private static String status = "Active";
	
	
	
			  @Test
			  public void performPOST() {
	  
	  				
	  				JSONObject myReqBody = new JSONObject();
	  				
	  				myReqBody.put("name", "Sudharsan");
	  				myReqBody.put("email", "Sudharsan@testuser");
	  				myReqBody.put("gender", "Male");
	  				myReqBody.put("status", "Active");
	  				
	  				RequestSpecification myPostRequest = 
	  				given().
			  				body(myReqBody.toJSONString()).
			  				header("Content-Type","application/json");
	  				
	  				Response myPostResponse = 
	  						myPostRequest.
	  						when().
	  							post(stringURI).
	  						then().
	  							extract().
	  							response();
	  				
	  				id = myPostResponse.jsonPath().getInt("id");
	  				
	  				
	  				
	  				//Assert Status Code 
	  				
	  				assertEquals(myPostResponse.getStatusCode(),201);
	  				
	  				
	  				//Assert Response Attributes
	  				
	  				assertEquals(myPostResponse.jsonPath().get("name"), username, "Username is incorrect");
	  				assertEquals(myPostResponse.jsonPath().get("email"), email, "Email is incorrect");
	  				assertEquals(myPostResponse.jsonPath().get("gender"), gender, "Gender is incorrect");
	  				assertEquals(myPostResponse.jsonPath().get("status"), status, "Status is incorrect");
	  				
	  				System.out.println("My ID is : "+id);
	  				
	  				
	  				//performGet(id);
	  				
	  				
	  
	  				
	  
	  
			  }
			  
			  
			  
			 @Test
			  public static void performGet() {
				 
			
					  when().
					  		  get("https://gorest.co.in/public/v2/users/7381469").
					  then().
							  body("name",equalTo("Mrs. Bilwa Namboothiri")).
							  	and().
							  body("email", equalTo("mrs_bilwa_namboothiri@johnston.example")).
							  statusCode(200).
							  log().all();
					  
				  
				
			//	 System.out.println(myResponse.asString());
				  
				  
			  }
			 
			 
			 
			 @Test
			 public void myPost() {
				 
				 Map<String,Object> myMap = new HashMap<>();
				 
				 myMap.put("name", "S");
				 myMap.put("email", "S@gmail.com");
				 myMap.put("gender", "Male");
				 myMap.put("status", "Active");
				 
				 
				 JSONObject myRequestBody = new JSONObject(myMap);
				 
				 given().
				 		body(myRequestBody).
				 when().
				 		post("https://gorest.co.in/public/v2/users/").
				 then().
				 		statusCode(anyOf(is(200),is(201))).and().body("name",equalTo("S"))
				 		.and().body("email",equalTo("S@gmail.com"))
				 		.log().all()
				 		;
				 
				 
				 
			 }
	  
	  			
			  
			  
}
