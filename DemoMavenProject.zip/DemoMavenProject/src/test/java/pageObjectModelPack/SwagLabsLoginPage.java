package pageObjectModelPack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.annotations.Test;

public class SwagLabsLoginPage {
	
		public WebDriver driver;
		
	
		SwagLabsLoginPage(WebDriver driver){
			
			this.driver = driver;
			
		}
		
		//Locate Elements using @FindBy
		
		@FindBy(how=How.ID,using="user-name") WebElement username;
		@FindBy(how=How.ID,using="password") WebElement password;
		@FindBy(how=How.ID,using="login-button") WebElement loginButton;
		
		@Test
		public void performLogin(String userName, String passWord) throws Exception {
			
			Thread.sleep(3000);
			username.sendKeys(userName);
			Thread.sleep(3000);
			password.sendKeys(passWord);
			Thread.sleep(3000);
			loginButton.click();
			
			
		}
		
		
		
	
	
}
