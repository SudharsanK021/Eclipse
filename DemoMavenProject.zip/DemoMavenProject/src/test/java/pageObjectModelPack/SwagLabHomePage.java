package pageObjectModelPack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

public class SwagLabHomePage {
	
	
	
	public WebDriver driver;
	
	
	
	SwagLabHomePage(WebDriver driver){
		this.driver = driver;
	}
	
	
	@FindBy(how=How.XPATH, using="//div[text()='Swag Labs']") WebElement homeTitle;
	
	@FindBy(how=How.XPATH, using="//span[text()='Products']") WebElement productsTitle;
	
	
	public void assertSuccessfulLogin() throws Exception{
		
		Thread.sleep(3000);
		Assert.assertEquals(homeTitle.getText(), "Swag Labs", "Home Page Title Assertion Failed");
		Assert.assertEquals(productsTitle.getText(), "Products", "Home Page Title Assertion Failed");
		
	}
	
	

}
