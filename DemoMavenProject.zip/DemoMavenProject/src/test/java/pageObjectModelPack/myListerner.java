package pageObjectModelPack;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

public class myListerner extends TestListenerAdapter{

	@Override
	public void onTestSuccess(ITestResult tr) {
		System.out.println("Success");
	}

	@Override
	public void onTestFailure(ITestResult tr) {
		System.out.println("Failure");
	}

	@Override
	public void onTestSkipped(ITestResult tr) {
		System.out.println("Skipped");
	}

	@Override
	public void onStart(ITestContext testContext) {
			
		System.out.println("onStart");
	
	}

	@Override
	public void onFinish(ITestContext testContext) {
		System.out.println("OnFinish");
	}

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("onTestStart");
	}
	
	
	
  
}
