package pageObjectModelPack;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;


public class takeScreenshots {
	
	public WebDriver driver;
	
	takeScreenshots(WebDriver driver){
		this.driver = driver;
	}
	
	
	@Test
	public void getScreenshot() throws Exception {
		
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://images.google.com/");
//		driver.manage().window().fullscreen();
		
		LocalDateTime dateTime = LocalDateTime.now();
		DateTimeFormatter dt = DateTimeFormatter.ofPattern("_yyyy_MM_dd_HH_mm_ss");
		String stringFormat = dateTime.format(dt);
		
		TakesScreenshot takeScreenshot = (TakesScreenshot) driver;
		File srcFile = takeScreenshot.getScreenshotAs(OutputType.FILE);
		File destFile = new File("C:\\Users\\sudharsa\\OneDrive - Capgemini\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src\\test\\java\\pageObjectModelPack\\NewImage"+stringFormat+".png");
		
		FileUtils.copyFile(srcFile, destFile);
		
		
		
	}

}
