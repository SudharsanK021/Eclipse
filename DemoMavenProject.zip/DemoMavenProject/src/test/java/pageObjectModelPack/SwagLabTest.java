package pageObjectModelPack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;


public class SwagLabTest{
	
	public WebDriver driver;
	
	@BeforeTest
	public void setup() {
		
			driver = WebDriverManager.chromedriver().create();
			driver.get("https://www.saucedemo.com/");
			driver.manage().window().maximize();
		
	}



	@Test
	public void performLogin() throws Exception{

		SwagLabsLoginPage swagLogin = PageFactory.initElements(driver, SwagLabsLoginPage.class);
		
		
		SwagLabHomePage homePage = PageFactory.initElements(driver, SwagLabHomePage.class);
		
		//takeScreenshots tk = PageFactory.initElements(driver, takeScreenshots.class);
		
		
		//Perform Login directly using the WebElement
		//swagLogin.username.sendKeys("standard_user");
		//swagLogin.password.sendKeys("secret_sauce");
		
		
		//Using the Page's in-built Method
		
		swagLogin.performLogin("standard_user", "secret_sauce");
		
		
		// Verify or Validate successful Login
		homePage.assertSuccessfulLogin();
		
		//Take Screenshot
		
		takeScreenshots tk = new takeScreenshots(driver);
		
		tk.getScreenshot();
		
		

	}
	
	
	
	@AfterTest
	public void tearDown() {
		
			driver.quit();
		
	}
}
