package getScreenshotPackage;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class DemoTest extends ActionLibrary{

	@Test(testName="NewTest")
	public void logintoSauceLab() {

		open("https://www.saucedemo.com/", "ChroMe");
		driver.findElement(By.xpath("null"));

	}

}
