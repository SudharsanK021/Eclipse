package getScreenshotPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class ActionLibrary {

			public static WebDriver driver;
			public static int executionNumber = 0 ;
			public static String executionFolder;
			public static String timeStamp;
		
			//Setup and Launch Browser
			public static void open(String uRL, String browserType) {
		
				switch(browserType.toLowerCase()) {
				case "edge":
					WebDriverManager.edgedriver().setup();
					driver = new EdgeDriver();
		
				case "chrome":
					WebDriverManager.chromedriver().setup();
					driver = new ChromeDriver();
		
				}
		
				driver.get(uRL);
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
		
				System.out.println("BrowserLaunched");
		
			}
			
			//Get Screenshot of Current Windows Handle
			public static void getScreenshot(String filename) throws Exception {
				
				LocalDateTime dt = LocalDateTime.now();
				executionFolder = dt.format(DateTimeFormatter.ofPattern("MMddyyyy"));
				timeStamp = dt.format(DateTimeFormatter.ofPattern("HHmmss"));
				
				
				
				TakesScreenshot screenshot = (TakesScreenshot) driver;
				File scFile = screenshot.getScreenshotAs(OutputType.FILE);
				String destFile = "C:\\Users\\sudharsa\\OneDrive - Capgemini"
						+ "\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src"
						+ "\\test\\ResourcesScreenshots\\"+"Execution_"
						+executionFolder+"\\"+filename+"_"+timeStamp+".jpg";
				FileUtils.copyFile(scFile,new File(destFile));
		
			}
		
		
		
		
		
		
		
			// This Method uses Dependency Injection Concept to Take Screenshot during runtime
			@AfterMethod
			public void afterMethodScreenCapture(ITestResult result) throws Exception {
				if(result.getStatus() == 1 || result.getStatus() == 2 ) {
					getScreenshot(result.getTestContext().getName()+"_"+result.getName());
				}
			}
		
		
			@AfterTest
			public static void tearBrowser() {
				if(driver != null) {
					driver.quit();
				}else {
					System.out.println("Driver is not initialized");
				}	
				System.out.println("BrowserTearedDown");
			}






}
