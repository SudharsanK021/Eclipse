package getScreenshotPackage;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class NewListenerClass extends ActionLibrary implements ITestListener{

	@Override
	public void onTestFailure(ITestResult result){

		try {
			//These method will use the method name from the TestNG Class
			//getScreenshot(result.getName());
			//getScreenshot(result.getMethod().getMethodName());


			getScreenshot(result.getTestContext().getName()+"_"+result.getName());

		} catch (Exception e) {
			e.printStackTrace();
		}


	}




}
