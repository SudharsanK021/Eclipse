package getScreenshotPackage;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Base64;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class getScreenshot {
	@Test()
	public void screenshotFileType() throws Exception {
		
	/*
	 * Classes Used: FileUtils, FileUtils.copyFile,File
	 * Interface Used: TakeScreenshot, TakeScreenshot.getScreenshotAs
	 */

		try {
			WebDriverManager.edgedriver().setup();
			WebDriver driver = new EdgeDriver();
			driver.get("https://images.google.com/");
			driver.manage().window().fullscreen();

			TakesScreenshot getScreenshot = (TakesScreenshot) driver;
			File srcFile = getScreenshot.getScreenshotAs(OutputType.FILE);
			File destFile = new File("C:\\Users\\sudharsa\\OneDrive - Capgemini\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src\\test\\ResourcesScreenshots\\NewImage.png");
			FileUtils.copyFile(srcFile, destFile);

			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}


	}
	
	
	
	@Test
	public void screenshotBase64Type() throws Exception {
		
		/*
		 * Classes Used: Base64.getDecoder().decode, FileOutputStream
		 * Interface Used: TakeScreenshot, TakeScreenshot.getScreenshotAs
		 */

		try {
			WebDriverManager.edgedriver().setup();
			WebDriver driver = new EdgeDriver();
			driver.get("https://images.google.com/");
			driver.manage().window().fullscreen();

			TakesScreenshot getScreenshot = (TakesScreenshot) driver;
			
			String base64 = getScreenshot.getScreenshotAs(OutputType.BASE64);
			System.out.println(base64);
			
			System.out.println(Base64.getDecoder().decode(base64));
			
			// Convert the base64 String to Byte[] using Decorder Methods from BASE64 Class
			
			byte[] byteDecoded = Base64.getDecoder().decode(base64);
			
			// Use FileOutput stream to wrtie the bytearray to File
			
			FileOutputStream fos = new FileOutputStream(new File(
			"C:\\Users\\sudharsa\\OneDrive - Capgemini\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src\\test\\ResourcesScreenshots\\NewImageBase64.png"));
			
			fos.write(byteDecoded);
			
			fos.close();
			
			
			
			driver.quit();
			
		} catch (Exception e) {
			e.printStackTrace();
		}


	}
	
	
	@Test
	public void screenshotByteArrType() throws Exception {
		
		/*
		 * Classes Used: FileOutputStream
		 * Interface Used: TakeScreenshot, TakeScreenshot.getScreenshotAs
		 */

		try {
			WebDriverManager.edgedriver().setup();
			WebDriver driver = new EdgeDriver();
			driver.get("https://images.google.com/");
			driver.manage().window().fullscreen();

			TakesScreenshot getScreenshot = (TakesScreenshot) driver;
			
			byte[] byteArr = getScreenshot.getScreenshotAs(OutputType.BYTES);
			
			// Use FileOutput stream to write the byteArray to File
			
			FileOutputStream fos = new FileOutputStream(new File(
			"C:\\Users\\sudharsa\\OneDrive - Capgemini\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src\\test\\ResourcesScreenshots\\NewImageByteArr.png"));
			
			fos.write(byteArr);
			
			fos.close();
			
			
			
			driver.quit();
			
		} catch (Exception e) {
			e.printStackTrace();
		}


	}
	
	

}
