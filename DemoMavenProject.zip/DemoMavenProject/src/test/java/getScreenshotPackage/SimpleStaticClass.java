package getScreenshotPackage;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.testng.annotations.Test;


public class SimpleStaticClass {
	
	
	@Test
	public void datePrinter() {
			LocalDateTime dt = LocalDateTime.now();
			String executionFolder = dt.format(DateTimeFormatter.ofPattern("HHmmss"));
			String timeStamp = dt.format(DateTimeFormatter.ofPattern("MMddyyyy"));
			
			
			String destFile = "C:\\Users\\sudharsa\\OneDrive - Capgemini"
					+ "\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src"
					+ "\\test\\ResourcesScreenshots\\"+"Execution_"
					+executionFolder+"\\"+"File"+"_"+timeStamp+".jpg";
			
			
			System.out.println(destFile);
	}
}