package _RestAssuredIO;

import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;


public class SimpleDeleteRequest {
	
			
		  @Test
		  public void deleteRequest() {
			  
			  baseURI = "https://reqres.in";
			
			  Response myResponse = 
			  when().
			  	delete("/api/users/2");
			  
			  myResponse.
			  then().
			  	statusCode(204);
			  
			  String statusLine = myResponse.then().extract().statusLine();
			  
			  System.out.println(statusLine.contains("No Content"));
			  
			  
			  
			  System.out.println(myResponse.getStatusCode()+"  "+myResponse.getStatusLine());
			  
			  
		  
			  	
		  
		  }
		  
  
  
}
