package _RestAssuredIO;



import org.testng.annotations.Test;
import static org.testng.Assert.*;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

// This class is used to perform assertions. And it is also used to assert & validation JSON Schema
import static io.restassured.matcher.RestAssuredMatchers.*;

// Used for assertions as well
// It has multiple methods like:
/*
 * equalTo
 * containsString
 * startsWith
 * endsWithhasSize
 * hasItems
 * 
 */
// This code is example : body("data[0].email",equalTo("michael.lawson@reqres.in")).log().all();
import static org.hamcrest.Matchers.*;

@SuppressWarnings("unused")
public class SimpleGETRequest {
	
	//@Test
	public void validateGet() {
		
		Response res = get("https://reqres.in/api/users?page=2");
		
		assertEquals(res.getStatusCode(), 200,"Status Code Assertion Failed");
		
		
		
	}
	
	//@Test
	public void bddStyleValidateGet() {
		
		given().
		get("https://reqres.in/api/users?page=2").
		then().
		statusCode(201).
		body("data[0].id", equalTo(7)).
		and().
		body("data[0].email",equalTo("michael.lawson@reqres.in")).log().all();
		
		
		
		
	}
	
	
	@Test
	//This function will use BDD style but stores the response in Response Object
	public void bddStyleButStoreResultInResponse() {
		
		Response myResponse = 
				given().
					get("https://reqres.in/api/users?page=2").
				then().
					statusCode(anyOf(is(200),is(201))).
					extract().
					response();
		
		System.out.println(myResponse.jsonPath().getString("data[0].email"));
				
		
		
		
		
		
	}
	
	
	
	
}
