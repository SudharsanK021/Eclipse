package _RestAssuredIO;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

public class SimplePostRequest {
	
	
				
			  @Test
			  public void usingMAP() {
				  
				  // Create a Map
				  
				  Map<String, Object> myMap = new HashMap<>();
				  
				  myMap.put("name", "Sudharsan");
				  myMap.put("job", "QA");
				  
				  System.out.println(myMap);
				  
				  // Create a JSONObject to convert map to JsonRequest
				  
				  JSONObject myRequestBody = new JSONObject(myMap);
				  
				  System.out.println(myRequestBody);
				  
				  //Convert the JSONObject.request to pure JSONString
				  System.out.println(myRequestBody.toJSONString());
				  
			  }
			  
			  
			  
				
			  @Test
			  public void usingJSONObjectRequest() {
				  
				  
				  // Create JSONObject for Request Body
				  
				  JSONObject myRequest = new JSONObject();
				  
				  myRequest.put("name", "Sudharsan");
				  myRequest.put("job", "QA Analyst");
				  
				  
				  validateSimplePOSTRequest(myRequest);
				  
				  
			  }
			  
			  @Test
			  public static void validateSimplePOSTRequest(JSONObject myRequest) {
				  
				  
				  	// Create BaseURI
				  
				  baseURI = "https://reqres.in/api";
				  
				  // Use Cucumber BDD to send Request and Validate Response
				  
				  
				  RequestSpecification myGiven = 
						  given().
					  		body(myRequest).
					  		header("Content-Type","application/json");
					
					
					
				  Response myWhen= 
						  myGiven.
						  when().
					  		post("/users");
						  
				  
				  
				  myWhen.
				  then().
				  		statusCode(201).
				  and().
				  		body("name",equalTo("Sudharsan")).
				  and().
				  		body("job",equalTo("QA Analyst")).log().all();
				  
				  
				  
			  }
			  
  
}
