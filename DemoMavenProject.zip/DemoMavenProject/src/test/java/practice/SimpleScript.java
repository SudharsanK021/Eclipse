package practice;

import org.testng.Assert;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SimpleScript {
	
private static WebDriver driver;

  @BeforeTest
  public void initialSetup() {
	  
	  
	  System.setProperty("webdriver.chrome.driver","path of chrome driver");
	  
	  driver = new ChromeDriver();
	  
	  driver.get("URL");
	  
	  
  }
	
  @Test
  @Parameters({"username","password","welcomeText"})
  public void loginFunction(String username, String password, String welcomeText) {
	  
	  driver.findElement(By.xpath("username")).sendKeys("testuser2");
	  
	  driver.findElement(By.xpath("password")).sendKeys("Test@5678");
	  
	  driver.findElement(null).click();
	  
	  Assert.assertEquals(driver.findElement(null).getText(), "Welcome to the website","Login is unsuccessful");
	  
	  
  }
  
  
  @AfterTest
  public void tearDown() throws IOException {
	  
	  SimpleScript.getScreenshot();
	  
	  driver.quit();
  }
  
  
  public static void getScreenshot() throws IOException {
	  
	  String filePath = "";
	  
	  File newFile = new File(filePath);
	  
	  File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	  
	  FileUtils.copyFile(newFile, screenshot);
	  
	  
  
  }
  
  
}
