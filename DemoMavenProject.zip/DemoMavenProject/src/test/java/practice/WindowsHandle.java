package practice;

import java.time.Duration;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.*;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WindowsHandle {
  @Test
  public void f() {
	  
	  WebDriver driver = WebDriverManager.chromedriver().create();
	  
		
	  System.setProperty("webdriver.chromedriver.driver", ".//BrowserServer//chromedriver.exe") ;
	 
	  
	  WebElement e = driver.findElement(null);
	  Select newS = new Select(e);
	  
	  
	  newS.getOptions();
	  
	  
	  // Actions
	  
	  Actions a = new Actions(driver);
	  
	  a.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).click().build().perform();
	  a.click();
	  a.build().perform();
	  
	  
	  /*
	  WebDriver driver = WebDriverManager.chromedriver().create();
	  
	
	  System.setProperty("webdriver.chromedriver.driver", ".//BrowserServer//chromedriver.exe") ;
	  
	  WebDriver driver = new ChromeDriver();
	  
	 
	  Actions action = new Actions(driver);
	  
	  action.move
	  
	  
	  
	  driver.navigate().to("https://www.javatpoint.com/");
	  
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	 
	  driver.manage().window().maximize();
	  
	  String originalWindowHandle = driver.getWindowHandle();
	  
	  WebElement sql = driver.findElement(By.xpath("(//a[normalize-space()='SQL'])[1]"));
	  
	  //Actions Keyword
	  
	  Actions action = new Actions(driver);
	  
	  action.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).keyUp(Keys.CONTROL).click(sql).keyUp(Keys.SHIFT).build().perform();
	  
	  
	  //Get Windows Handles
	  
	  Set<String> windoHandles = driver.getWindowHandles();
	  
	  for (String currentWindow : windoHandles) {
		  
		  if(originalWindowHandle!=currentWindow) {
			  
			  driver.switchTo().window(currentWindow);
			  
			  //perform any logic or action
			  driver.close();
			    
		  }
		  
	  }
	  
	  
	  driver.switchTo().window(originalWindowHandle);
	  
	  
	  driver.quit();
	  
	 
	  */
	  
  }
}
