package practice;

import java.util.*;
import java.util.Map.Entry;

public class Map_ValueRepetion {

	public static void main(String[] args) {

		int [] arr = new int[] {1,2,1,2,3,4};
		
		
		Map<Integer,Integer> map = new HashMap<>();
		
		System.out.println(map);
		
		for(int i=0 ; i < arr.length ; i++ ) {
			
			// get the element and add the count
				 for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
					 
					 if( ( ((Map<Integer, Integer>) map).containsKey(arr[i]))) {
				
						 map.put(arr[i], (((Entry<Integer, Integer>) map).getValue())+1);
						 
					
					 }else {
						
						 map.put(arr[i],1);
						 
					 }
			}
			
		}
		
		System.out.println(map);
		
		

	}

}
