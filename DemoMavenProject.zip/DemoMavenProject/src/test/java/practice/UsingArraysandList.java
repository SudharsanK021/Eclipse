package practice;

import java.util.*;

public class UsingArraysandList {
	
	public static void createArrays() {
		
		String s[] = new String[] {"Sudharsan", "Kumar"};
		
		List<String> s1 = new ArrayList<String>(Arrays.asList("Sudharsan","Kumar"));
		
		List<String> s2 = new ArrayList<String>();
		
		s2.add("Sudharsan");
		
		
		
		System.out.println(Arrays.toString(s));
		System.out.println(s1);
		System.out.println(s2);
		
	}
	
	
	public static void useArray() {
		
		String names [] = new String[] {"s"};
		//or
		String [] names2 = {"Alic","Bccc","Ccccc"};
		
		
		
		System.out.println(names+" "+names2);
		
		Arrays.sort(names);
		Arrays.sort(names , Collections.reverseOrder());
	
	}
	
	
	
	public static int[] sortArrayAsc(int [] numbers){
		
		
		//int[] numbers = {1,4,100,7,2,9,3,0,1999,1995,1997};
		
		
		System.out.println(Arrays.toString(numbers));
		
		for(int i = 0 ; i < numbers.length; i ++) {
			
			System.out.println(i +" = i  ");
			
			int temp = 0 ; 
			
			for(int j = i+1 ; j < numbers.length; j++  ) {
				
				System.out.println(j +" = j  ");
				
				if(numbers[i] > numbers[j]) {
					
					temp = numbers[i];
					numbers[i] = numbers[j];
					numbers[j] = temp;
					
					/*
					numbers[i] = numbers[i] + numbers[j];
					numbers[j] = numbers[i] - numbers[j];
					numbers[i] = numbers[i] - numbers[j]; 
					*/
					System.out.println(Arrays.toString(numbers));
					
				}
				
				
				
			}
			
			
		}
		
		System.out.println(Arrays.toString(numbers));
		
		return numbers;
		
		
		
		
	}
	
	
	public static void sortArrayDesc() {
		
		int[] numbers = {1,4,100,7,2,9,3,0,1999,1995,1997};
		
		for(int i = 0 ; i < numbers.length ; i++) {
			
			int temp = 0 ; 
			
			for (int j = i+1; j < numbers.length; j++) {
				
					if (numbers[i] < numbers[j]) {
							
							temp = numbers[i];
							numbers[i] = numbers[j];
							numbers[j] = temp;
						
					}
				
				
			}
			
		}
		
		
	}
	
	
	
	public static int getNthNumberFromArray(int rank, int [] numbers) {
		
		int sortedArray [] = UsingArraysandList.sortArrayAsc(numbers);
		
		if(rank != 0 && rank < numbers.length) {
		System.out.println(sortedArray[rank-1]);
		return sortedArray[rank-1];
		}
		else{
			System.out.println("Provided rank is out of index in Array");
			return rank;
		}
		
		
	}
	
	
	public static void useArrayList() {
		
		List <String> newList = new ArrayList<>(Arrays.asList("A","B","A")) ;
		
		
		newList.add("C");
		newList.remove("A");
		newList.remove(1);
		
		System.out.println(newList);
		
		System.out.println(newList.contains("A"));
		
		
		
		
		//Sort Array in Ascending order
		
		
		List<Integer> num = new ArrayList<Integer>(Arrays.asList(1,4,100,7,2,9,3,0,1999,1995,1997));
		
		for(int i = 0; i < num.size() ; i++ ) {
			
			int temp = 0 ; 
			
			for(int j = i+1 ; j < num.size(); j++) {
					
				
					if(num.get(i) > num.get(j)) {
					temp = num.get(i);
					num.set(i, num.get(j));
					num.set(j, temp);
					
					}
				
			}
			
			
		}
		
		System.out.println(num);
		
		
		
		//Sort Array in Descending order
		
		
				List<Integer> num2 = new ArrayList<Integer>(Arrays.asList(1,4,100,7,2,9,3,0,1999,1995,1997));
				
				for(int i = 0; i < num2.size() ; i++ ) {
					
					int temp = 0 ; 
					
					for(int j = i+1 ; j < num2.size(); j++) {
							
						
							if(num2.get(i) < num2.get(j)) {
							temp = num2.get(i);
							num2.set(i, num2.get(j));
							num2.set(j, temp);
							
							}
						
					}
					
					
				}
				
				System.out.println(num2);
		
		
		
		
		
	}
	

	public static void main(String[] args) {
		int[] numbers = {1,4,100,7,2,9,3,0,1999,1995,1997};
		
		UsingArraysandList.sortArrayAsc(numbers);
		
		UsingArraysandList.getNthNumberFromArray(10, numbers);
		
		UsingArraysandList.useArrayList();
		
		
		UsingArraysandList.createArrays();
		
		
		UsingArraysandList.useArray();

		

	}

}
