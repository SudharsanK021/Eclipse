package practice;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class retrieveTableDataBasedOnCondition {


	@Test
	public static void readExcelForTableData() throws IOException{

		String filePath = System.getProperty("user.dir")+"\\src\\test\\java\\practice\\dynamic_table.xlsx";

		File file = new File(filePath);

		FileInputStream fin = new FileInputStream(file);

		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fin);

		XSSFSheet sheet = workbook.getSheetAt(0);

		int rowCount = sheet.getPhysicalNumberOfRows();

		XSSFRow row;

		List<String> countriesWithSpecificLanguage  = new ArrayList<>();

		System.out.println(rowCount);

		for (int i = 0; i < rowCount; i++) {

			row = sheet.getRow(i);

			if(row != null) {

				System.out.println("Specified Row exist in row index : "+i);

				if(row.getCell(3).getStringCellValue().equals("English")) {


					countriesWithSpecificLanguage.add(row.getCell(0).getStringCellValue());



				}

			}else {

				System.out.println("Specified Row doesn't exist in row index : "+i);

			}



		}



		if(countriesWithSpecificLanguage.size() > 0) {

			System.out.println("The Countries which has English as Primary Languages are :");

			System.out.println(countriesWithSpecificLanguage);

		}else {

			System.out.println("No country has English as Primary Language");

		}






	}

	@Test
	public static void retrieveTableContent() {

		


	}
}
