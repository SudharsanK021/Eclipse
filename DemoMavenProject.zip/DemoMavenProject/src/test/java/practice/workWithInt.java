package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class workWithInt {
	
	public static void removeDuplicates() {
		
		List<Integer> num = new ArrayList<Integer>(Arrays.asList(1,4,1999,1999,100,7,1997,4,2,2,9,3,0,1999,1995,1997));
		
		System.out.println(num.size());
		
		for(int i = 0 ; i < num.size(); i++) {
			
			for(int j = i+1 ; j < num.size(); j++) {
				
				//if( i != j ) {
					
					if ( num.get(i).compareTo(num.get(j)) == 0  ) {
						
							num.remove(j);
							
					}
					
					
				//}
				
			}
			
			
		}
		
		
		
		
		
		Collections.sort(num);
		
		System.out.println(num);
		
	
		
		
	}

	public static void main(String[] args) {
		workWithInt.removeDuplicates();

	}

}
