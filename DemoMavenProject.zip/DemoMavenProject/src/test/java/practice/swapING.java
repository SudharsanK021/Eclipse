package practice;

public class swapING {
	
	public static void swapInt() {
		
				int a = 1999;
				int b = 2000;
				
				//Swap numbers
				
				a = a + b ; //a = 3999
				b = a - b ; //b = 1999
				a = a - b ; //a = 2000
				
				System.out.println(a +" "+b);
				
			
	}
	
	
	public static void swapString() {
		
				String a1 = "Sudha";
				String b1 = "rsan";
			
				
				
				a1 = a1 + b1; //Sudharsan
				b1 = a1.substring(0 , a1.length() - b1.length()); //(0 , 5 )
				a1 = a1.substring((a1.length() - b1.length()) + 1 , a1.length());
				
				
				System.out.println(a1 +"  "+b1);
						
		
	}
	
	
	public static void main(String[] args) {
		
		
		swapING.swapInt();
		swapING.swapString();
		
				
				
				
				
		
	}

}
