package practice;

import java.util.Iterator;

public class StarPatter1 {

	public static void main(String[] args) {


	//Pattern1
			for (int i = 0; i <= 5; i++) {
				
				for (int j = 0; j <= i; j++) {
					
					System.out.print("*");
				}
				
				System.out.println();
				
			}	
		
			
			System.out.println("///////////////////////////");
			
	//Pattern2
			
			for (int i = 5; i > 0 ; i--) {
				
				for (int j = i; j > 0; j--) {
					
					System.out.print("*");
				}
				
				System.out.println();
				
			}	
			
			

			
			System.out.println("///////////////////////////");
			
			
		//Pattern3
			
			
			int nnn = 5;
			
			for (int i = 0; i < nnn ; i++) {
				
				for (int j = i; j < nnn-1 ; j++) {
					
					System.out.print(" ");
				}
				
				for (int k = 0; k < (i + 1) ; k++) {
					System.out.print("*");
				}
				System.out.println();
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		
		

	}

}
