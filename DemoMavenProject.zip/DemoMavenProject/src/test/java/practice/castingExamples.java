package practice;

public class castingExamples {

	public static void main(String[] args) {

		int a = 10;

		char ch = (char) a;
		
		int c = (int) 'z';

		int b = Integer.parseInt("21101999");

		String s = String.valueOf(a);

		System.out.println(c);




	}

}
