package practice;

public class workWithString {
	
	public static String stringRev(String original) {
		
		String rev = "";
		
		for (int i = original.length()-1; i >= 0  ; i--) {
			
			rev = rev + original.charAt(i);
			
		}
		
		return rev;
		
		
	}
	
	public static void checkPalindrome(String original) {
		
		
		
		if(workWithString.stringRev(original).toLowerCase().equals(original.toLowerCase())) {
			System.out.println("The given string is a palindrome");
		}else {
			System.out.println("No...the given string isn't a palindrome");
			
		}
			
		
		
	}
	

	public static void main(String[] args) {


		
		workWithString.checkPalindrome("Geeks");
		
		
		
		

	}

}
