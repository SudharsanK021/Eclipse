package tempPackage;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import pageObjectModelPack.myListerner;
@Listeners({myListerner.class})
public class NewTest {
 
  WebDriver driver;
	
	@Test
	public void myTestMethod() throws InterruptedException {
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		
		//Explicit Wait
		
		WebDriverWait wdw = new WebDriverWait(driver, Duration.ofMillis(3000));
		wdw.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='user-name']")));
		
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(3000));
		
		
		
		Thread.sleep(3000);

	}
}
