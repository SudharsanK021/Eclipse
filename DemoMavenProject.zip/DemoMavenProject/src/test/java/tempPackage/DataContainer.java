package tempPackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataContainer {

	@DataProvider(name="dataContainerList", indices = {0,1})
	@Test
	public Iterator<String[]> dataContainerList() {

		List<String[]> myList = new ArrayList<String[]>();

		myList.add(new String[] {"Sudha","Pass1"});
		myList.add(new String[] {"Dharsan","Pass2"});


		return myList.iterator();

	}

	@DataProvider(name="dataContainerStringArray", indices = {0,1})
	@Test
	public String[][] dataContainerStringArray() {
		
		String [][] strArray = new String[][] {{"Sudharsan","Password"},{"Sudharsan2","Password2"}};
		
		return strArray;
		
		

		
	}


}
