package tempPackage;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pageObjectModelPack.myListerner;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

/*
This Class has Sample Annotation steps of 
@Test
@BeforeSuite
@AfterSuite
@BeforeClass
@AfterClass
@BeforeMethod
@AfterMethod
@BeforeTest
@AfterTest
 */

@Listeners({myListerner.class})
public class AnnotationsSample {

	
	
	@Parameters({"username","password"})
	
	@Test(groups = {"test"},dataProvider = "dataContainerStringArray", dataProviderClass = DataContainer.class)
	public void testMethod(String user, String pass) {
		System.out.println(user+" As part of Test Method  "+pass);
		
		
		
	}

	@Test(groups = {"test2"})
	public void testMethod2() {
		System.out.println("testMethod2");
		String str1 = "Sudharsan";
		String str2 = "Sudharsan2";
		
		SoftAssert sA  = new SoftAssert();
		
		sA.assertEquals(str1.equals(str2), true,"hey don't match");
		
		sA.assertAll("There is an assertion Error Occured");
		
	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("beforeMethod");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("afterMethod");
	}

	@BeforeClass
	public void beforeClass() {
		System.out.println("beforeClass");
	}

	@AfterClass
	public void afterClass() {
		System.out.println("afterClass");
	}

	@BeforeTest
	public void beforeTest() {
		System.out.println("beforeTest");
	}

	@AfterTest
	public void afterTest() {
		System.out.println("afterTest");
	}

	@BeforeSuite
	public void beforeSuite() {
		System.out.println("beforeSuite");
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("afterSuite");
	}


}
