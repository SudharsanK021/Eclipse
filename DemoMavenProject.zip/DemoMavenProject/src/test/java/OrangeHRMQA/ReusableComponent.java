package OrangeHRMQA;


import static org.testng.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ReusableComponent {

	public static WebDriver driver;
	public static WebElement element;

	//Soft Assert instantiation
	SoftAssert softassert = new SoftAssert();

	@BeforeTest
	public void browserInitialization() throws Exception{

		driver = WebDriverManager.chromedriver().create();

		driver.get("https://opensource-demo.orangehrmlive.com/");

		driver.manage().window().maximize();

		Thread.sleep(5000);

	}

	@Test(testName = "ValidLogin", enabled = true, priority = 0)
	public void login() throws Exception {

		String forgotPassword = locateElement("XPATH","//p[normalize-space()='Forgot your password?']").getText();
		String LoginPageHeader = locateElement("XPATH","//h5").getText();

		//Login Page

		softassert.assertEquals(forgotPassword, "Forgot your password?");
		softassert.assertEquals(LoginPageHeader, "Login");
		locateElement("CSS","input[name='username']").sendKeys("Admin");
		locateElement("CSS","input[name='password']").sendKeys("admin123");

		//Assert the Elements before Login
		softassert.assertAll();

		Thread.sleep(3000);

		locateElement("CSS","button[type='submit']").click();

		Thread.sleep(5000);

		System.out.println("LoginDone");
		

	}

	@Test(testName = "InvalidLogin", enabled = false, priority = 1)
	public void invalidLogin() throws Exception {

		locateElement("CSS","input[name='username']").sendKeys("Admin");
		locateElement("CSS","input[name='password']").sendKeys("admin", Keys.ENTER);

		Thread.sleep(2000);

		softassert.assertEquals(locateElement("XPATH","//p[text()='Invalid credentials']").getText(), "Invalid credentials", "Credentials entered are valid");
		softassert.assertAll();
		


	}

	@Test(testName = "DashboardAssertion", enabled = true, priority = 1)
	public void dashboardAssertionUponLogin() {
		
/*		assertEquals(true,locateElement("XPATH","//img[@alt='client brand banner']").isDisplayed(),"Sucess1");
		assertEquals("Dashboard",locateElement("XPATH","//header//*[text()='Dashboard']").getText(),"Sucess2");
		assertEquals("Paul Collings",driver.findElement(By.cssSelector("p.oxd-userdropdown-nam")).getText(),"Login is unsuccessfull");
	*/
		
		assertEquals("Paul Collings",driver.findElement(By.cssSelector("p.oxd-userdropdown-name")).getText(),"Login is unsuccessfull");
		System.out.println("DashboardDone");
		
	}
	
	

	public static WebElement locateElement(String locatorType , String locator) {
		switch (locatorType.toLowerCase()) {
		case "xpath":
		{
			element = driver.findElement(By.xpath(locator));
			break;
		}
		case "css":
		{
			element = driver.findElement(By.cssSelector(locator));
			break;
		}
		}
		return element;
	}



	@AfterTest
	public void browserTearDown() {

		driver.quit();

	}

}
