package _RestAssuredIO_JSONSchemas;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.module.jsv.JsonSchemaValidator.*;

public class ValidateSchemaRegRes {
  @Test
  		public void schemaValidator() {
  		
	  		when().
	  			get("https://reqres.in/api/users?page=2").
	  		then().
	  			assertThat().
	  				body(matchesJsonSchemaInClasspath("mySchema.json"));
	  		
  
  		}
}
