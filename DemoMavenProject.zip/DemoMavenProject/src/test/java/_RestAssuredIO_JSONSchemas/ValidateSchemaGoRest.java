package _RestAssuredIO_JSONSchemas;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.module.jsv.JsonSchemaValidator.*;

public class ValidateSchemaGoRest {
  @Test
  public void getRequest() {
	  
	  when().
	  		get("https://gorest.co.in/public/v2/users").
	  then().
	  		assertThat().
	  		body(matchesJsonSchemaInClasspath("mySchemaGoRest.json"));
	  
	  
  }
}
