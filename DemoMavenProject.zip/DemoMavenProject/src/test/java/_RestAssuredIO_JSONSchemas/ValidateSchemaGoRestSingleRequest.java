package _RestAssuredIO_JSONSchemas;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.module.jsv.JsonSchemaValidator.*;

public class ValidateSchemaGoRestSingleRequest {
				  @Test
				  public void getRequest() {
					  //mySchemaGoRestSingleRequest.json
					  
					  when().
					  		get("https://gorest.co.in/public/v2/users/7381471").
					  then().
					  		assertThat().
					  		body(matchesJsonSchemaInClasspath("mySchemaGoRestSingleRequest.json"));
					  
					  
					  
				  }
				  
				  
				  
				  
}
