package dataProviderPackage;

import org.testng.annotations.*;

public class DP_Practice {
  @Test
  @DataProvider(name="testDP")
  public Object[][] dataProviderMethod() {
	  String s[][] = new String[][] {{"chrome","www.google.com","Hello"},{"edge","www.google.com","Hello"}};
	  return s; 
  }
  
  @Test(dataProvider = "testDP", dataProviderClass = DP_Practice.class)
  public void testThis(String browser, String url, String welcomeMessage) {
	  
	  System.out.println(browser+" "+url+" "+welcomeMessage);
	  
  }
  
  
  
  
}
