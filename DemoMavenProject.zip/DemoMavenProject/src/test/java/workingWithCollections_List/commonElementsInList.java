package workingWithCollections_List;

import java.util.*;

public class commonElementsInList {

	public static void main(String[] args) {
		List<Integer> list1 = Arrays.asList(1, 2, 2, 3, 4, 5);
		List<Integer> list2 = Arrays.asList(2, 3, 5, 7);

		//First method
		Set<Integer> mySet1 = new HashSet<>(list1);
		Set<Integer> mySet2 = new HashSet<>(list2);

		mySet1.retainAll(mySet2);

		//System.out.println(mySet1);

		//Second method
		List<Integer> list3 = new ArrayList<>();

		for (int i = 0; i < list1.size(); i++) {

			for (int j = 0; j < list2.size(); j++) {


				if(list1.get(i) == list2.get(j)) {

					if(!list3.contains(list1.get(i))) {
						list3.add(list1.get(i));
					}

				}

			}

		}


		System.out.println(list3);



	}

}
