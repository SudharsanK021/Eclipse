package workingWithCollections_List;

import java.util.*;

public class getSecondLargestInteger {

	public static void main(String[] args) {
			
			List<Integer> myList = new ArrayList<>();
			myList.add(2);
			myList.add(1999);
			myList.add(1998);
			myList.add(1);
			
			
			
			for (int i = 0; i < myList.size(); i++) {
				
				for (int j = i+1; j < myList.size(); j++) {
					
						if(myList.get(i) > myList.get(j)) {
					
						myList.set(i, myList.get(i) + myList.get(j));
						myList.set(j, myList.get(i) - myList.get(j));
						myList.set(i, myList.get(i) - myList.get(j));
						
						
						
						}
					
				}
				
				
				
			}
			
			
			System.out.println("Second Largest number is: "+myList.get(myList.size()-2));
			
			

	}

}
