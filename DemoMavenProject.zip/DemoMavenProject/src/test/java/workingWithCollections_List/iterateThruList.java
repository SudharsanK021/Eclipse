package workingWithCollections_List;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class iterateThruList {


	public static void addValuesToList(int[] arr, CopyOnWriteArrayList<Integer> myList) {

		for (int i = 0; i < arr.length; i++) {

			myList.add(i, arr[i]);

		}

		System.out.println(myList);

	}

	public static void removeDuplicatesfromList(CopyOnWriteArrayList<Integer> myList) {

		int tempCount = 0 ; 

		Iterator<Integer> iterateOriginalList = myList.iterator();

		while(iterateOriginalList.hasNext()) {


			for (int i = 0; i < myList.size(); i++) {

				
				if(iterateOriginalList.next().equals(myList.get(i)) && tempCount < 1) {
					tempCount++;
				}else {
					if(tempCount == 1) {
						myList.remove(i);
						tempCount = 0 ;
					}
					
				}

			}



		}

		System.out.println(myList);	
		
		
		
		

	}

	public static void main(String[] args) {
		
		int [] arr = new int[] {1,2,1,2,3,4};

		CopyOnWriteArrayList<Integer> myList = new CopyOnWriteArrayList<>();

		iterateThruList.addValuesToList(arr,myList);
		iterateThruList.removeDuplicatesfromList(myList);

	}

}
