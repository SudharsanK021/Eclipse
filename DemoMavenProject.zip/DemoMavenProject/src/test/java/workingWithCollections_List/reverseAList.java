package workingWithCollections_List;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class reverseAList {

	public static void main(String[] args) {
		List<Integer> numbers = new CopyOnWriteArrayList<>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(2);
		numbers.add(3);
		numbers.add(4);
		numbers.add(4);
		numbers.add(5);
		
		//Collections.sort(numbers,Collections.reverseOrder());
		
		//Collections.sort(numbers);
		
		System.out.println("Before reversing a List: "+numbers);
		//Reverse a List
		//Own Technique
		
		int temp = 0;
		for (int i = 0; i < numbers.size(); i++) {

				int j = (int)(Math.floor(numbers.size() / 2)) ;
				
				if( j!= i) {
				System.out.println("First Index: "+numbers.get(i)+" Last Index: "+(numbers.get(numbers.size() - (i+1))));
				temp = numbers.get(i);
				numbers.set(i, (numbers.get(numbers.size() - (i+1))));
				numbers.set((numbers.size() - (i+1)), temp);
				}
				
				
		}
		
		System.out.println(numbers);
		
	}

}
