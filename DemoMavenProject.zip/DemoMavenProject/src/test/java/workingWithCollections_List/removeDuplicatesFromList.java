package workingWithCollections_List;

import java.util.*;

public class removeDuplicatesFromList {

	public static void removeUsingSet(List<Integer> numbers) {


		System.out.println("This is List :"+ numbers);
		
		Set<Integer> set = new HashSet<>(numbers);

		System.out.println("This is set :"+ set);


	}

	public static void removeUsingForLoop(List<Integer> numbers) {
		
			List <Integer> tempList = numbers;
		
			int count= 0 ; 

			for (int i = 0; i < tempList.size(); i++) {
				
					for (int j = 0; j < tempList.size(); j++) {
						
						if(tempList.get(i).equals(tempList.get(j))) {
							count = count +1 ; 
						}
						if(count > 1) {
							tempList.remove(j);
							count = 1; // This step is main
						}
						
					}
					count = 0;  // This step is main
				
			}
			
			System.out.println(tempList);

	}

	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<>();
		numbers.add(1);
		numbers.add(1);
		numbers.add(1);
		numbers.add(1);
		numbers.add(2);
		numbers.add(2);
		numbers.add(3);
		numbers.add(4);
		numbers.add(4);
		numbers.add(5);
		
		System.out.println(numbers);

		removeDuplicatesFromList.removeUsingForLoop(numbers);
		//removeDuplicatesFromList.removeUsingSet(numbers);

	}
	
	//1,1,1,1,2,2,3,4,4,5
	
	
	public static void praC(List<Integer> numbers) {
		
		int tempCount = 0;
		
		for (int i = 0; i < numbers.size(); i++) {
			
			for (int j = 0; j < numbers.size(); j++) {
				
					if(numbers.get(i) == numbers.get(j)) {
						tempCount = tempCount+1;
					}
					
					if(tempCount > 1) {
						numbers.remove(j);
						tempCount = 1;
					}
				
			}
			
			tempCount = 0 ; 
			
		}
		
		
		
	}
	

}
