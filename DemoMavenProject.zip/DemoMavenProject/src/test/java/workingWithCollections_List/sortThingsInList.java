package workingWithCollections_List;

import java.util.*;

public class sortThingsInList {

	public static List<String> sortString(List<String> fruits) {

		for (int i = 0; i < fruits.size(); i++) {
			for (int j = i+1; j < fruits.size(); j++) {

				// The Logic is as follows:
				// Less than Zero = > The strings are in Ascending order
				// Zero => The Strings are equal
				// More than Zero => The Strings are in Descending Order

				if(fruits.get(i).compareTo(fruits.get(j)) > 0) {
					String temp = fruits.get(i);
					fruits.set(i, fruits.get(j));
					fruits.set(j, temp);

				}

			}
		}

		System.out.println(fruits);

		return fruits;




	}

	public static void sortIntList(List<Integer> num) {



		for (int i = 0; i < num.size(); i++) {

			for (int j = i+1; j < num.size(); j++) {

				if(num.get(i) < num.get(j)) {

					int temp = num.get(i);
					num.set(i, num.get(j));
					num.set(j, temp);

				}


			}

		}

		System.out.println(num);



	}

	public static void main(String[] args) {

		List<String> fruits = new ArrayList<>();

		fruits.add("Banana");
		fruits.add("Apple");
		fruits.add("Orange");
		fruits.add("Mango");
		fruits.add("A");
		fruits.add("B");
		fruits.add("C");


		sortThingsInList.sortString(fruits);

		List<Integer> num = Arrays.asList(1,2,8,9,9,3,5,4,2,3,6,9);

		sortIntList(num);

	}









}
