package parallelThreads;

import org.testng.annotations.Test;


public class ParallelClass {
			
	
	
		@Test
		public void method1() {
			System.out.println("Method 1 , Thread "+ Thread.currentThread().getId());
		}
		
		@Test
		public void method2() {
			System.out.println("Method 2 , Thread "+ Thread.currentThread().getId());
		}
		@Test
		public void method3() {
			System.out.println("Method 3 , Thread "+ Thread.currentThread().getId());
		}
		@Test
		public void method4() {
			System.out.println("Method 4 , Thread "+ Thread.currentThread().getId());
		}
		
		@Test
		public void method5() {
			System.out.println("Method 5 , Thread "+ Thread.currentThread().getId());
		}
		@Test
		public void method6() {
			System.out.println("Method 6 , Thread "+ Thread.currentThread().getId());
		}
		@Test
		public void method7() {
			System.out.println("Method 7 , Thread "+ Thread.currentThread().getId());
		}
		@Test
		public void method8() {
			System.out.println("Method 8 , Thread "+ Thread.currentThread().getId());
		}
	
}
