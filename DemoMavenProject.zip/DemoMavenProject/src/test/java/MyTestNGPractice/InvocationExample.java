package MyTestNGPractice;

import org.testng.annotations.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.AfterTest;
//import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

//*************************************************
//*
//*	The below class demonstrates the example of InvocationCount , ThreadPoolSize and InvocaionTimeOut Parameters
//*
//*************************************************

public class InvocationExample {

	private WebDriver driver;

	//	@BeforeTest
	//	public void initializationOfDriver() {
	//		
	//		WebDriverManager.chromedriver().setup();
	//		driver = new ChromeDriver();
	//		driver.manage().window().maximize();
	//		driver.get("https://www.saucedemo.com/");
	//	}

	
	
	
	
	
	//*************************************************
	//*XMLSuite used is invocationParametersXML. I have mentioned two tests in XML Suite and the Invocation Count is 2
	//*So each testcase will execute twice and provide results
	//*
	//*************************************************

	
	
	@Test(invocationCount = 2)
	@Parameters({"browserURL","username","password"})
	public void simpleLogin(String browserURL, String username, String password) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(browserURL);


		////////////////////////////
		// Login Functionality
		////////////////////////////


		Thread.sleep(3000);

		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(3000);

		driver.quit();

	}


	//	@AfterTest(alwaysRun = true)
	//	public void nullifyDriverInitialization() {
	//		
	//		driver.quit();
	//		
	//	}

}


















