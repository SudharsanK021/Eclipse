package MyTestNGPractice;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.internal.thread.ThreadTimeoutException;

public class TimeOutAndExpectedExceptionEx {
	
	private static WebDriver driver;
	//************************
	// Here in the below method Iam providing timeOut as 6 Seconds, 
	//So the given method execution should complete by 6 Seconds
	//************************
	
	//************************
	// Iam expecting that ThreadTimeoutException may occur nbecause the below Test Method 
	// execution will not complete by 6 Seconds
	// If it didnt complete and then this method will throw the exception which Iam expecting
	//************************
	
	@Test(timeOut = 6000, expectedExceptions = {ThreadTimeoutException.class})
	public static void timeOutExample() {
		
		System.setProperty("webdriver.chrome.driver", ".//BrowserServer//chromedriver.exe");

		// Instantiate the Driver Server Object


			driver  = new EdgeDriver();
		

			driver.get("https://www.saucedemo.com");

		
		
	}
	
	public void f() {
		
		
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 * 
		 * wait.until(ExpectedConditions.)
		 */
		
		//Assert.assertThrows("The thrown exception doesn't match", ThreadTimeoutException.class, TimeOutAndExpectedExceptionEx.timeOutExample());
		
	}
}
