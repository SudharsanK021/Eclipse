package MyTestNGPractice;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SampleTest {
  @Test
	  public void f() {
	  
	  WebDriver driver = WebDriverManager.chromedriver().create();
	  
	  driver.manage().window().maximize();
		driver.get("https://www.youtube.com/");
	 
	  
	  }
}
