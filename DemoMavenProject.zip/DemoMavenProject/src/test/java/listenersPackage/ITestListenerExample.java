package listenersPackage;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ITestListenerExample implements ITestListener{

	@Override
	public void onTestStart(ITestResult result) {
		/*
		 * Can be used to provide the Testcase name and used Parameter
		 */
		System.out.println("onTestStart");
		System.out.println("******Test Execution has started....."
					   + "\n******Test Case :"+result.getTestName()
					   + "\n********************************");
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("onTestSuccess");
		System.out.println("******Test Case Passed....."
				   + "\n******Test Case :"+result.getTestName()+" has been passed...."
				   + "\n********************************");		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("onTestFailure");
		System.out.println("******Test Case Failed....."
				   + "\n******Test Case :"+result.getTestName()+" has been failed...."
				   + "\n******Failure Reason :"+result.getThrowable()
				   + "\n********************************");	
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("onTestSkipped");
		System.out.println("******Test Case Skipped....."
				   + "\n******Test Case :"+result.getTestName()+" has been skipped...."
				   + "\n******Failure Reason :"+result.getSkipCausedBy().iterator()
				   + "\n********************************");	
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		System.out.println("onTestFailedButWithinSuccessPercentage");
		System.out.println("******Test Case Failed but under Success Percentage....."
				   + "\n******Test Case :"+result.getTestName()+" has been skipped...."
				   + "\n******Failure Reason :"+result.getSkipCausedBy().iterator()
				   + "\n********************************");
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		System.out.println("onTestFailedWithTimeout");
		System.out.println("******Test Case Failed due to timeout....."
				   + "\n******Test Case :"+result.getTestName()+" has been skipped...."
				   + "\n******Test Case took :"+result.getEndMillis()+" which is more than specified time"
				   + "\n********************************");
		
	}

	@Override
	public void onStart(ITestContext context) {
		System.out.println("onStart");
		System.out.println("\n********************************"+
				"******On Start Execution has invoked"
				+ "\n********************************");
	}						
							
	@Override
	public void onFinish(ITestContext context) {
		/*
		 * Can also use to upload the status to db
		 */
		System.out.println("onFinish");
		
		/*
		 * Can be used to provide the Final Report with Total Count and Pass Percentage
		 */
		System.out.println("******Executed has been completed"
				+ "\n******Saving the Reports"
				);
		System.out.println(
				"\n==============================================="+
				  "\n******Total Test Cases 				:"+context.getPassedTests().size()
				+ "\n******Total Passed     				:"+context.getPassedTests().size()
				+ "\n******Total Failed     				:"+context.getFailedTests().size()
				+ "\n******Total Skipped    				:"+context.getSkippedTests().size()
				+ "\n******Current XML Test  				:"+context.getCurrentXmlTest().getName()
				+ "\n******Reports has been placed under 	:"+context.getOutputDirectory()
				+ "\n******TestSuite Execution occured here	:"+context.getHost()
				// Since the execution happened locally the hostname would be null
				+ "\n********************************"
				+"\n===============================================");
	}	
		


}
