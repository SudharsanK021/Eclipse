package listenersPackage;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

/*
 * This class demonstrates how we can extend TestListenerAdapter Class and use methods of ALL LISTENERS in TestNG
 */

public class ITestListenerAdapterClass extends TestListenerAdapter{

	@Override
	public void onTestStart(ITestResult result) {
		
		System.out.println("Test Case <"+result.getTestName()+"> has been invoked for execution");
		System.out.println("Current Status"+result.getStatus());
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Test Case <"+result.getTestName()+"> has been Passed");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Exception"+result.getThrowable()+" has occured during execution");
		System.out.println("Test Case <"+result.getTestName()+"> has been Failed");	
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("Exception"+result.getThrowable()+" has occured during execution");
		System.out.println("Test Case <"+result.getTestName()+"> has been Skipped");	
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		System.out.println("Exception"+result.getThrowable()+" has occured during execution");
		System.out.println("Test Case <"+result.getTestName()+"> has been Failed but ignored due to Success Percentage Precedence");
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		System.out.println("Exception"+result.getThrowable()+" has occured during execution");
		System.out.println("Test Case <"+result.getTestName()+"> Failed with time out error");
		System.out.println(result.getTestName()+""+result.getEndMillis());
	}

	@Override
	public void onStart(ITestContext context) {
		System.out.println("Run has been triggered......");
	}						
							
	@Override
	public void onFinish(ITestContext context) {
		System.out.println("Execution status is complete......"
				+ "\nReports are getting generated......"
				+ "\nReports are placed under......"+context.getOutputDirectory()
				);
		System.out.println(
				"\n==========================================================="
				+ "\n*******EXECUTION SUMMARY*******"	
				+ "\nTotal Test Cases :"+context.getPassedTests()
				+ "\nTotal Passed     :"+context.getPassedTests().size()
				+ "\nTotal Failed     :"+context.getFailedTests().size()
				+ "\nTotal Skipped    :"+context.getSkippedTests().size()
				+ "\nCurrent XML Test :"+context.getCurrentXmlTest().getName()
				+"\n===========================================================");
		
				
	}	
		


}

