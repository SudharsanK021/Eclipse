package listenersPackage;

import org.testng.Assert;
//import org.testng.annotations.Listeners;
import org.testng.annotations.*;
///import listenersPackage.ITestListenerExample;

@Test(testName = "SimpleTest", successPercentage = 50)
@Listeners({ITestListenerExample.class})
public class ITestListenerTestClass {

	@Test(priority = 1,enabled=true)
	public void passTest() {
		System.out.println("Pass Test");
	}

	@Test(priority = 2,timeOut = 1000,enabled=false)
	public void failTestwithTimeOut() throws Exception {
		try {
		Thread.sleep(3000);
		System.out.println("Test Failed with Time out");
		}catch(Exception e) {System.out.println("Time Out Exception Occured");}
	}
	
	@Test(priority = 3,enabled = false)
	public void failTest() {
		Assert.assertTrue(false);
		System.out.println("Fail Test");
	}
	
	@Test(priority = 4, dependsOnMethods = {"failTest"} ,enabled = false)
	public void skipTest() {
		System.out.println("Skip Test");
	}
	
	
}
