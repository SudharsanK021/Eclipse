package workingWithCollectionsSet;

import java.util.*;

public class removeDuplicatesfomSet {

	public static void removeIntDuplicates(int [] arr) {

		Set<Integer> mySet = new HashSet<>();

		for (int i = 0; i < arr.length; i++) {

			mySet.add(arr[i]);

		}

		System.out.println(mySet);


	}

	public static void removeStringDuplicates(String[] stringArr) {

		Set<String> mySet = new HashSet<>();

		for (int i = 0; i < stringArr.length; i++) {

			mySet.add(stringArr[i]);

		}

		System.out.println(mySet);


	}


	public static void main(String[] args) {

		int intArr[] = {1,2,3,4,1,2};
		
		String stringArr[] = {"Sudharsan","Sudha","Dharsan","Sudharsan","Apple","Zebra"};
		
		System.out.println(intArr.toString());
		
		System.out.println(stringArr[0].compareTo(stringArr[3]));
		System.out.println(stringArr[0].compareTo(stringArr[4]));
		System.out.println(stringArr[0].compareTo(stringArr[5]));

		//removeDuplicatesfomSet.removeIntDuplicates(intArr);
		//removeDuplicatesfomSet.removeStringDuplicates(stringArr);

	}

}
