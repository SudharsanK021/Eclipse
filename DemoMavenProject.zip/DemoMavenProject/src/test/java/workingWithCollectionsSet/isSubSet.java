package workingWithCollectionsSet;

import java.util.*;

public class isSubSet {

	public static void main(String[] args) {
		Set<Integer> setA = new HashSet<>();
		setA.add(1);
		setA.add(2);
		setA.add(3);

		Set<Integer> setB = new HashSet<>();
		setB.add(0);
		setB.add(3);

		
		// One Way
		// Iterate and find if the Size of smaller set is same as the matching count
		

		System.out.println("Contains************");
		
		int tempCount = 0;
		
		Iterator<Integer> iterateSetB = setB.iterator();
		while(iterateSetB.hasNext()) {
			
			int tempB = iterateSetB.next();

			Iterator<Integer> iterateSetA = setA.iterator();
			
			while(iterateSetA.hasNext()) {
				
				int tempA = iterateSetA.next();
				
				
				if( tempB== tempA ) {
					
					tempCount++;
					
				}
			}	
		}
		
		if(tempCount == setB.size()) {
			System.out.println("SetB is a subset of SetA");
		}else {
			System.out.println("SetB isn't a subset of SetA");
		}
		
		
		// Other Way
		// Use containsAll method
		
		System.out.println("ContainsAll************");
	
		if(setA.containsAll(setB)) {
			System.out.println("SetB is a subset of SetA");
		}else {
			System.out.println("SetB isn't a subset of SetA");
		}


	}

}
