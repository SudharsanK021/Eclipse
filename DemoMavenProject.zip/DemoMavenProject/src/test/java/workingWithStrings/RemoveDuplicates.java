package workingWithStrings;

public class RemoveDuplicates {
	
	public static void usingStringBuilder(){
	    
	    StringBuilder s = new StringBuilder("aaabbhddkjkkkkaaoow");
	    
	    // remove duplicates
	    
	    for(int i = 0 ; i < s.length(); i++){
	      
	        for(int j = i+1 ; j < s.length(); j++){
	            
	              if(s.charAt(i) == s.charAt(j)){
	                
	                  s.deleteCharAt(j);
	                  
	                  j--; // Adjust j's Index to make the StringBuilder dynamic
	                
	              }
	        
	        }System.out.println(s);
	      
	    }    
			
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub
	    usingStringBuilder();

		}

	}
