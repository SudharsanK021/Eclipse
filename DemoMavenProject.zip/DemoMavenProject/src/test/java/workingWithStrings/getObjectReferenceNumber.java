package workingWithStrings;

public class getObjectReferenceNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "Sudharsan";

		System.out.println(System.identityHashCode(s));

		s = "Kumar";

		System.out.println(System.identityHashCode(s));

		/*String Methods 
			
			replace
			substring
			concat
			
	    */
		StringBuilder sb = new StringBuilder();

		sb.append("Sudharsan");

		System.out.println(System.identityHashCode(sb));

		sb.append(" Kumar");

		System.out.println(System.identityHashCode(sb));
		
		System.out.println(sb);
		
		/*StringBuilder Methods 
		
		reverse
		append
		delete
		insert
		replace
		
    */




	}

}
