package workingWithStrings;

import java.util.Arrays;

public class CompressString {
	
	
	
	
	static StringBuilder sortStringBuilder(StringBuilder sb) {
	
		StringBuilder s = new StringBuilder(sb);
		
		char [] charArr = s.toString().toCharArray();
		
		Arrays.sort(charArr);
		
		StringBuilder s2 = new StringBuilder(new String(charArr));
		
		return s2;
		
		
	}

	static StringBuilder usingStringBuilder(StringBuilder sb) {

		StringBuilder s = sb;
		StringBuilder s2 = new StringBuilder();

		//take one value
		//iterate through the stringBuilder
		//value matches add count to Varibale => Count
		//Then add it to the new String Builder
		//If a is already present in new String Builder then skip

		int count = 0;

		for (int i = 0; i < s.length(); i++) {

				for (int j = 0; j < s.length(); j++) {
	
					if (s.charAt(i) == s.charAt(j)) {
	
						count = count + 1 ; 
	
					}
	
				}
				
				if(!s2.toString().contains(s.substring(i,i+1))) {
	
					s2.append(s.charAt(i));
					s2.append(count);
	
				}
				
				count = 0 ;

		}
		
		if(s.length() > s2.length()) {
			
			System.out.println("Compressed String : "+s2.toString());
			
		}else {
			System.out.println("Original String : "+s.toString());
		}
		
		return s;
		
		


	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		usingStringBuilder(sortStringBuilder(new StringBuilder("aaahhdbalhwjdwwqqw")));
		
		
	}

}
