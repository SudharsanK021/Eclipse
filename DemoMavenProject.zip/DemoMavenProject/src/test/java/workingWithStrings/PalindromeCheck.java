package workingWithStrings;

public class PalindromeCheck {
	
	static void usingStringBuilder(StringBuilder s) {
		
		StringBuilder s2 = new StringBuilder();
		
		for (int i = s.length(); i > 0; i--) {
			
			s2.append(s.charAt(i-1));
			
		}
		
		if(s2.compareTo(s) == 0 ) {
			System.out.println("String is a Palindrome");
		
		
		}
		
		System.out.println(s +" "+s2 );
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		usingStringBuilder(new StringBuilder("Mom"));

	}

}
