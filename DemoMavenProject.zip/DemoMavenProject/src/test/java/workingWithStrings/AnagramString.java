package workingWithStrings;

import java.util.Arrays;

public class AnagramString {
	
	static void usingStringBuilderUsingAnagram() {
		
		/*
		 * String 1: "listen"
		 * String 2: "silent"
		 */
		
		// Iterate thorugh second String using char of first String
		// increment the count Varibale
		// end of second iteration if count is less than one, increment the count2 Variable
		// End of out Iteration => if count2 is equal to length of s1 then anagram
		
		StringBuilder s = new StringBuilder("listen");
		StringBuilder s2 = new StringBuilder("silent");
		
		
		int count = 0, count2 = 0;
		
		for (int i = 0; i < s.length(); i++) {
			
				for (int j = 0; j < s2.length(); j++) {
					
						if(s.charAt(i) == s2.charAt(j)) {
							count  = count + 1;
						}
					
				}
				
				if(count == 1) {
					count2 = count2 + 1;
				}
				
				System.out.println(count+" "+count2);
				count = 0 ;
				
		}
		
		if(count2 == s.length()) {
			System.out.println("Both the strings are anagram");
		}else {
			System.out.println("Strings are not anagram");
		}
		
		
		
		
	}
	
	static void usingCompressionTechnique() {
		
		StringBuilder s = new StringBuilder("listen");
		StringBuilder s2 = new StringBuilder("silent");
		
		
		StringBuilder s3 = CompressString.usingStringBuilder(CompressString.sortStringBuilder(s));
		StringBuilder s4 = CompressString.usingStringBuilder(CompressString.sortStringBuilder(s2));
		
		if(s3 == s4) {
			System.out.println("Its a anagram");
		}else {
			System.out.println("Not an Anagram");
		}
		
		System.out.println(s3+" "+s4);
		
		
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//usingStringBuilderUsingAnagram();
		
		usingCompressionTechnique();

	}

}
