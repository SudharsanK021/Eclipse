package workingWithStrings;

import java.util.Arrays;

public class StringBuilderInsertion {

	static void usingStringBuilder(){

		StringBuilder s = new StringBuilder("Sudharsan Kumar");
		StringBuilder s2 = new StringBuilder();

		// Reverse String without reversing the characters
	
		String [] strArr = s.toString().trim().split(" ");
		
		System.out.println(Arrays.toString(strArr));

		for (int i = strArr.length; i > 0 ; i--) {
			
			s2.append(strArr[i-1]);
			
			if( i != strArr.length-1) {
				s2.append(" ");
			}
			
			
		}
		
		System.out.println(s2);



	}
	
	static void insertionAtGivenIndex() {
		StringBuilder s = new StringBuilder("Sudharsan");
		
		s.insert(s.length(), " Kumar");
		
		System.out.println(s);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		usingStringBuilder();
		
		insertionAtGivenIndex();

	}

}
