package workingWithStrings;

import java.util.HashMap;
import java.util.Map;

public class NonRepeatingCharacter {
	
	
	static void usingStringBuilder() {
		
		StringBuilder s = new StringBuilder("aaabbcbbdddccc");
		Map<Character, Integer> myMap = new HashMap<>();
		
		//Iterate through the String and add that character and its frequency in map

		for (int i = 0; i < s.length(); i++) {
			
			if(myMap.get(s.charAt(i)) != null) {
				
					
					myMap.put( s.charAt(i) , myMap.get( s.charAt(i) ) + 1  );
				
				
			}else {
					
					myMap.put(s.charAt(i), 1);
				
			}
			
			
		}
		
		System.out.println(myMap);
		
		int tempCount = 0 ;
		
		for ( Map.Entry<Character,Integer> entry : myMap.entrySet() ) {
			
				if(entry.getValue() == 1) {
						
						System.out.println("The Non Repetative Character in Given String is : "+ entry.getKey());
						
						tempCount = tempCount+1;
					
				}
			
		}
		
		if(tempCount == 0 ) {
			System.out.println(-1);
		}
		
			
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		usingStringBuilder();

	}

}
