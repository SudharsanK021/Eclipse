package workingWithStrings;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class FindLargestSubtring {
	
	static void usingStringBuilder(String s) {
		
		StringBuilder sB = new StringBuilder(s);
		
		// Iterate with outer and inner loop
		// if not equal => keep record of index while traversing
		// even if one match is found then skip that inner loop iteration 
		// and use the last recorded index and i to add the key value to map
		
		System.out.println(sB.length());
		
		int lastIndex = 0,firstIndex = 0 ;
		
		Map <String,Integer> m = new HashMap<>();
		
		
		for (int i = 0; i < sB.length(); i++) {
			
			for (int j = i+1; j < sB.length(); j++) {
				
				
					if( sB.charAt(i) != sB.charAt(j) ) {
						
						firstIndex = i; //3
						lastIndex = j+1; // 6
						
					}
					else if(sB.charAt(j) == sB.charAt(j+1) && ((j+1) != sB.length())){
						
						firstIndex = i; //3
						lastIndex = j+1; // 6
						break;
						
						
					}
					else {
					
							break;
					
					}
					
				
			}
			
			if( lastIndex == sB.length()) {
				
				System.out.println("IF "+firstIndex+"  "+lastIndex);
				m.putIfAbsent( (s.substring(firstIndex)), (s.substring(firstIndex)).length());
				
			}else if (lastIndex > 0 ){
				
				System.out.println("ELSE "+firstIndex+"  "+lastIndex);
				m.putIfAbsent( (s.substring(firstIndex, lastIndex)), (s.substring(firstIndex, lastIndex)).length());
				
			}
			
			
			
		}
		
		System.out.println(m);
		 
		for (Map.Entry<String, Integer> entry : m.entrySet()) {
	            if (entry.getValue().equals(Collections.max(m.values()))) {
	                System.out.println("Biggest Substring Length is " + Collections.max(m.values()) + " and its subString is: " + entry.getKey());
	            }
	        }
		
		
		
		
		
	}

	public static void main(String[] args) {
		
		usingStringBuilder("aaabcdefgg");

	}

}
