package workingWithStrings;

public class RotateString {

	static void usingStringBuilder() {

		StringBuilder s = new StringBuilder("Hello");

		for (int i = 0; i <= ( Math.floor( s.length() % 2 ) ); i++) {

			char temp = s.charAt(i);

			s.insert(i , s.charAt( s.length() - i - 1 ) );

			s.insert( s.length() -i , temp );


		}

		System.out.println(s);


	}

	static void usingStringBuilder2() {

		int rotateAxis = 2;

		StringBuilder s = new StringBuilder("Hello");

		StringBuilder s2 = new StringBuilder();

		
		s2.append(s.substring(rotateAxis+1, s.length()));
		s2.append(s.substring(0, rotateAxis+1));

		System.out.println(s2);





	}



	public static void main(String[] args) {

		usingStringBuilder2();
		// TODO Auto-generated method stub

	}

}
