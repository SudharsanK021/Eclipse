package backToJavaBasics;

public class ExcampleofCheckedException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			throw new IllegalAgeCheckedCustomEx("This is to show the age is illegal exception");
			
		}catch(IllegalAgeCheckedCustomEx e) {
			
			System.out.println(e.getMessage());
			
		}

	}

}
