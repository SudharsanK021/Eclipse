package backToJavaBasics;

import java.util.LinkedList;

public class workingWithLinkedList {

	public static void main(String[] args) {
		LinkedList<String> linkedArrayList = new LinkedList<>();

		linkedArrayList.add("Sudharsan"); // 0
		linkedArrayList.add("Kumar"); //1
		linkedArrayList.add(1, "Sudha");

		System.out.println(linkedArrayList);
	}

}
