package backToJavaBasics;

public class IllegalAgeCheckedCustomEx extends Exception{

	
	
	IllegalAgeCheckedCustomEx(String message){
		super(message);
	}
	
}
