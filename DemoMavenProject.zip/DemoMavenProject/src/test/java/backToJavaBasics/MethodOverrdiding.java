package backToJavaBasics;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MethodOverrdiding extends BaseTest{

	private WebDriver driver;

			public MethodOverrdiding(WebDriver driver) {
				super(driver);
		
			}
		
		
		
			@Override
			@BeforeTest
			public void openUp() {
		
				super.openUp();
				driver.get("URL");
			}
		
			@Override
			@AfterTest
			public void tearDown() {
				driver.quit();
				System.out.println("Driver teardown was successful");
			}

}


class BaseTest{


			private WebDriver driver;
		
		
			public BaseTest(WebDriver driver) {
				this.driver = driver;
			}
		
			@BeforeTest
			public void openUp() {
		
				driver  = new ChromeDriver();
			}
		
			@AfterTest
			public void tearDown() {
				driver.quit();
			}



}