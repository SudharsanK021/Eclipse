package backToJavaBasics;

// This class extends RuntimeException (subclass of Exception class) which is used to for unchecked exception

public class IllegalArgumentUncheckedException extends RuntimeException {
	
	IllegalArgumentUncheckedException(String message){
		super(message);
	}

}
