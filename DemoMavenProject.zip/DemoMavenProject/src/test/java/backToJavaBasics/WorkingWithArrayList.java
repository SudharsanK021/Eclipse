package backToJavaBasics;

import java.util.ArrayList;

public class WorkingWithArrayList {

	public static void main(String[] args) {
		ArrayList<String> arrayList = new ArrayList<>();
		
		arrayList.add("Sudharsan"); // 0
		arrayList.add("Kumar"); //1
		arrayList.add(1, "Sudha");
		
		System.out.println(arrayList);

	}

}
