package backToJavaBasics;

public class ExcampleOfUncheckedException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int amountRequested = 80000;
		
		int balanceAvailable = 41000;
	
		try {
			if(amountRequested > balanceAvailable) {
				throw new IllegalArgumentUncheckedException("Balance is low than the requested amount");
			}
			else {
				System.out.println("Nothing");
			}
		}catch (RuntimeException e) {
				System.out.println(e.getMessage());
		}
	
	
	}

}
