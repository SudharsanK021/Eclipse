package backToJavaBasics;

public class ConstructorsAndGetters {
	
	private String user;
	private String password;
	
	
	//Parameterized Constructors
	public ConstructorsAndGetters(String user, String password){
		
		this.user = user;
		this.password = password;
		
		
	}
	

	//Default Constructors
	public ConstructorsAndGetters(){
		
		user = "U";
		password = "P";
		
		throw new ArithmeticException("Just for fun");
		
		
	}
	
	
	@Override
	public void finalize() throws Throwable{
		
		try {
			System.out.println("Perform your clean up logic here before the object si garbage collected");
			
		}finally {
			//call your superclass's finalize() method
			super.finalize();
		}
		
	}
	

	public String getUser() {
		return user;
	}

	public String getPassword() {
		return password;
	}


	public static void main(String[] args) throws Exception {
		
		ConstructorsAndGetters obj1 = new ConstructorsAndGetters("Username","Password");
		
		try {
		ConstructorsAndGetters obj2 = new ConstructorsAndGetters();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("The exception has been catched");
		}
		
		
		
		System.out.println(obj1.user+" "+obj1.password );
		//System.out.println(obj2.user+" "+obj2.password );
		//obj1.finalize();
		
		
		
		

	}

}
