package workingWithFiles;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.security.cert.X509Certificate;
import java.util.*;

import javax.net.ssl.*;

public class ProcessBooksList {
	
	 public static void disableSSLVerification() throws Exception {
	        // Create a trust manager that does not validate certificate chains
	        TrustManager[] trustAllCerts = new TrustManager[] {
	            new X509TrustManager() {
	                public X509Certificate[] getAcceptedIssuers() {
	                    return null;
	                }
	                public void checkClientTrusted(X509Certificate[] certs, String authType) { }
	                public void checkServerTrusted(X509Certificate[] certs, String authType) { }
	            }
	        };

	        // Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	     // Create an all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true; // Accept all hostnames
	            }
	        };
	        
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	    }
	
	
	static void processBooksfromURL() throws Exception{
		
		String urlPath = "https://public.karat.io/content/test/test_file.txt";
		
		URL urlObject = new URL(urlPath);
		
		URLConnection urlConnect = urlObject.openConnection();
		
		BufferedReader readContent = new BufferedReader(new InputStreamReader(urlConnect.getInputStream()));
		
		String line = "";
		
		String [] myString = null;
		
		Set<String> uniqueBookCount = new HashSet<>();
		
		int pagesCount = 0, booksCount = 0 ;
		
		while( ( line = readContent.readLine() ) != null) {
			
				System.out.println(line);
				
				myString = line.split(",");
				
				pagesCount = pagesCount + Integer.parseInt(myString[ ( myString.length ) - 1]);
				
				if( ( myString.length == 4 ) && ( myString[ ( myString.length ) - 2] != null ) ) {
					booksCount = booksCount + 1;
					uniqueBookCount.add(myString[ ( myString.length ) - 2]);
				}
			
		}
		
		System.out.println("Unique Book count: "+uniqueBookCount.size());
		System.out.println("Book count		 : "+booksCount);
		System.out.println("Page count		 : "+pagesCount);
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			disableSSLVerification();
			processBooksfromURL();
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
