package workingWithFiles;

import java.io.*;

public class ReadFileFromLocal {



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String filePath = "C:\\Users\\sudharsa\\OneDrive - Capgemini\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src\\test\\java\\workingWithFiles\\newFile.txt";


		try {

			BufferedReader br = new BufferedReader(new FileReader(filePath));

			String newLine;

			while((newLine = br.readLine()) != null) {

				String [] content = newLine.split("\\|\\|");

				for (int i = 0; i < content.length; i++) {

					if(content[2].contains("@gmail")) {
					
						System.out.print(content[i]+" ");
					
					}
					
				}System.out.println();

			}


		}catch(Exception e) {
			e.printStackTrace();
		}


	}

}
