package workingWithFiles;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class ReadFileFromURL {

	public static void main(String[] args) {


		String path = "https://www.learningcontainer.com/wp-content/uploads/2020/04/sample-text-file.txt";

		try {

			// Create a New File


			//File f = new File("./DemoMavenProject/src/test/java/workingWithFiles/newFile.txt");

			String f = "C:\\Users\\sudharsa\\OneDrive - Capgemini\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src\\test\\java\\workingWithFiles\\newFile.txt";

			//if(f.exists()) {

			// Read the contents from Network

			URL url = new URL(path);

			URLConnection uC = url.openConnection();

			//InputStreamReader gets the content in form of Input stream from URL and converts byte to characters 
			//BufferredReader will read the characters line by line

			BufferedReader br = new BufferedReader(new InputStreamReader(uC.getInputStream()));

			BufferedWriter bw = new BufferedWriter(new FileWriter(f));

			String line;

			while ((line = br.readLine()) != null) {

				System.out.println(line);

				bw.write(line); // Writes each line in the file
				bw.newLine();

			}

			System.out.println("Done and Dusted");


			//}else {
			//System.out.println("File doesn't exists");
			//}



		}
		catch(Exception e) {
			e.printStackTrace();
		}



	}

}
