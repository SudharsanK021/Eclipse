package seleniumPractice;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class playWithDropdowns {

	public WebDriver driver;
	public WebElement myDropdownElement;
	public Select myDropdown;

	@BeforeTest
	public void driverSetup() throws Exception {

		driver = WebDriverManager.chromedriver().create();

		driver.get("https://the-internet.herokuapp.com/");

		driver.findElement(By.xpath("//a[text()='Dropdown']")).click();

		Thread.sleep(3000);

		myDropdownElement = driver.findElement(By.xpath("//select"));

		myDropdown = new Select(myDropdownElement);



	}


	@Test
	public void selectDropdrownByVisibleText() throws Exception {


		//		List<WebElement> allOptions = myDropdown.getOptions();
		//
		//		

		//
		//			System.out.println(e.getAttribute("disabled"));
		//
		//			if(e.getAttribute("disabled") == null || e.getAttribute("disabled") != "true") {
		//
		//				System.out.println("It entered");
		//				myDropdown.selectByVisibleText(e.getText());
		//				Thread.sleep(4000);
		//
		//			}
		//
		//			System.out.println(e.toString());
		//
		//		}

		Thread.sleep(3000);

		myDropdown.selectByVisibleText("Option 1");



		Thread.sleep(3000);

		myDropdown.selectByVisibleText("Option 2");

		Thread.sleep(3000);

		List<WebElement> selectedOptions = myDropdown.getAllSelectedOptions();

		for(WebElement e : selectedOptions) {
			System.out.println(e.getText());
		}



	}

	@Test
	public void selectDropdrownByValue() throws Exception {

		/*
		List<WebElement> allOptions = myDropdown.getOptions();

		for(WebElement e : allOptions){

			if(e.getAttribute("value") != "") {

				System.out.println(e.getAttribute("value"));
				myDropdown.selectByValue(e.getAttribute("value"));
				Thread.sleep(3000);

			}

		}
		 */
		myDropdown.selectByValue("1");

		Thread.sleep(3000);

		myDropdown.selectByValue("2");

		Thread.sleep(3000);

	}

	@Test
	public void selectDropdrownByIndex() throws Exception {

		myDropdown.selectByIndex(1);

		Thread.sleep(3000);

		myDropdown.selectByIndex(2);

		Thread.sleep(3000);


	}

	@Test
	public void selectCustomDropdown()  throws Exception {

		myDropdownElement.click();

		driver.findElement(By.xpath("//option[text()='Option 1']")).click();

		Thread.sleep(3000);

		myDropdownElement.click();

		driver.findElement(By.xpath("//option[text()='Option 2']")).click();

		Thread.sleep(3000);



	}

	@AfterTest
	public void driverTearDown() {

		driver.quit();

	}




}
