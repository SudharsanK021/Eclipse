package seleniumPractice;

import org.testng.annotations.Test;

public class PlayWithFrames {
  @Test
  public void f() {
  }
}
