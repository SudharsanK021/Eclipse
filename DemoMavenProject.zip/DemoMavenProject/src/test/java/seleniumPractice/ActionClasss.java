package seleniumPractice;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Action;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ActionClasss {
	@Test
	public void f() throws Exception {

		WebDriver driver = WebDriverManager.chromedriver().create();

		driver.get("https://the-internet.herokuapp.com/");

		Thread.sleep(5000);

		WebElement link = driver.findElement(By.xpath("//a[text()='Multiple Windows']"));

		Actions action = new Actions(driver);

		action.scrollToElement(link).perform();

		Action openLinkInNewWindow = action.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).click(link).keyUp(Keys.SHIFT).keyUp(Keys.CONTROL).build();

		openLinkInNewWindow.perform();


		Thread.sleep(5000);

		Set <String> currentWindowHandles = driver.getWindowHandles();

		for(String s : currentWindowHandles ) {

			driver.switchTo().window(s);

			Thread.sleep(5000);

			System.out.println(driver.getCurrentUrl());

			if(driver.getCurrentUrl() == "https://the-internet.herokuapp.com/windows"){

				driver.findElement(By.xpath("//a[text()='Click Here']")).click();

				System.out.println("hello");

				Thread.sleep(6000);

			}

		}
	}

}
