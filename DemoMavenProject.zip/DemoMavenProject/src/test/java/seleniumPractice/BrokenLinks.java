package seleniumPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class BrokenLinks {
  @Test
  public void f() throws Exception{
	  
	  WebDriver driver = WebDriverManager.chromedriver().create();
	  
	  driver.get("https://the-internet.herokuapp.com/");
	  
	  driver.manage().window().maximize();
	  
	  
	  List<WebElement> myURLS = driver.findElements(By.xpath("//ul//li//a"));
	  Thread.sleep(3000);
	  
	  //for (int i = 0; i < myURLS.size(); i++) {
		  
		  //String url = myURLS.get(i).getAttribute("href");
	  
	  	  String url = "https://the-internet.herokuapp.com/abtest";
		  
		  URL urll = new URL(url);
		  
		  HttpURLConnection connection = (HttpURLConnection) urll.openConnection();
		  
		  connection.setRequestMethod("HEAD");
		  
		  connection.connect();
		  
		  int statusCode = connection.getResponseCode();
		  
		  if(statusCode >= 400) {
			  System.out.println("The given Link: "+url+" : is BROKEN with status code : "+statusCode);
		  }else {
			  System.out.println("The given Link: "+url+" : is VALID with status code : "+statusCode);
		  }
		  
	//}
	  
	 driver.quit(); 
	  
	  
  }
}
