package seleniumPractice;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NavigateOptions {

	public WebDriver driver;

	@Test
	public void driverSetup() throws Exception{

		driver = WebDriverManager.chromedriver().create();

		//driver.get("https://the-internet.herokuapp.com/");

		driver.navigate().to("https://the-internet.herokuapp.com/");

		Thread.sleep(5000);

		driver.navigate().back();

		Thread.sleep(5000);


		driver.navigate().forward();

		Thread.sleep(5000);

		driver.navigate().refresh();

		Thread.sleep(5000);
		
		driver.quit();



	}
}
