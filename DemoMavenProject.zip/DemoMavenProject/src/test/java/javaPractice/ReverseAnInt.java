package javaPractice;


public class ReverseAnInt {
	
	public static void intWay() {
		

				int digit = -1999;
				
				int reversed = 0 , num = 0 ;
				
				
				while(digit != 0) {
						
					num = digit%10;
					reversed = reversed * 10 + num ;
					digit = digit / 10;
					
					System.out.println(num+" "+digit);
					
				}
				
				System.out.println(num +"  "+reversed+"  "+digit);
				
				/*
				 * 
				 * number = digit % 10;
				 * reversedNum  = reversedNum * 10 + number
				 * digit = digit / 10;
				 * 
				 * 
				 */
	
		
	}
	
	
	public static void stringWay() {
		int digit = 1999;
		
		String digitS = Integer.toString(digit);
		
		String reversedDigitS = "";
		
		for (int i = digitS.length() ; i > 0  ; i --) {
			
			reversedDigitS += digitS.charAt(i-1);
			
		}
		
		System.out.println(Integer.parseInt(reversedDigitS));
		
		System.out.println(reversedDigitS);
	
		
	}
	
	
	public static void reverseString() {
		
		String s = "Hello Sudha, How are you";
		
		String reversed = "";
		
		for (int i = s.length(); i > 0 ; i--) {
			
			reversed = reversed + s.charAt(i-1);
			
		}
		
		System.out.println(reversed);
	}


	
	public static void main(String[] args) {
		
		
		ReverseAnInt.reverseString();
		
	}
	
	

}
