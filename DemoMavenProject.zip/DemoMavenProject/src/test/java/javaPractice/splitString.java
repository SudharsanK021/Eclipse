package javaPractice;

import java.util.*;
import java.util.Arrays;

public class splitString {
	
	
	public static void main(String [] args) {
		
			String s = "Sudharsan Kumar Holly Jollyyyyyy   ";
			String str [] = s.split(" ");
			System.out.println(str[(str.length)-1].length());
			
			 List<String> list = new ArrayList<>();
			 list.add("A");
			 list.add("B");
			 list.set(1, "C");
			 list.add("D");
			 System.out.println(list);
			
			
	}
	

}
