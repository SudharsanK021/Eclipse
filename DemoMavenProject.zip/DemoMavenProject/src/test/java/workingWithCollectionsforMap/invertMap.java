package workingWithCollectionsforMap;

import java.util.*;

public class invertMap {

	public static void main(String[] args) {
		Map<String, Integer> originalMap = new HashMap<>();
        originalMap.put("One", 1);
        originalMap.put("Two", 2);
        originalMap.put("Three", 3);
        
        Map<Integer,String> newMap = new HashMap<>();
        
       // One way 
       // Iterator<Map.Entry<String, Integer>> iterateMap = originalMap.entrySet().iterator();
        
       // Other way
       for(Map.Entry<String, Integer> myEntry : originalMap.entrySet()) {
    	   
    	   newMap.put(myEntry.getValue(), myEntry.getKey());
    	   
       }
       
       System.out.println("Original MAP: "+originalMap);
       System.out.println("Original MAP: "+newMap);
        
  
	}

}
