package workingWithCollectionsforMap;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;

public class iterateThruMap {

	public static int [] arr = new int[] {1,2,1,2,3,4};
	

	public static Map <Integer,Integer> egMap = new ConcurrentHashMap<>();

	public static int tempIndex = 0;

	public static void iterateMap(int [] intArray) {


		for (int i = 0; i < intArray.length; i++) {

			egMap.put(tempIndex, intArray[i]);

			tempIndex++;

		}


		System.out.println(egMap);



	}
	/*
	public static void findDuplicateinMapusingLoop() {

		List <Integer> tempkey = new ArrayList<>() ;

		// First Iteration through the MAP
		for(Map.Entry<Integer, Integer> entryMap : egMap.entrySet()){

			int keyMap = entryMap.getKey();
			int valueMap = entryMap.getValue();


			// Get the Key and Value from first Iteration and iterate again through the same map for comparison
			for(Map.Entry<Integer, Integer> innerMap : egMap.entrySet()){

				//Add map's key to a list
				if(innerMap.getValue() == valueMap) {

					tempkey.add(innerMap.getKey());


				}

			}


			// Once the Keys are added to the List. Verify the Size of the Key and Validate if the size is more than 1
			if(tempkey.size() > 1) {

				for (int i = 1; i < tempkey.size(); i++) {

					egMap.remove(tempkey.get(i));

				}
			}

		}


	}

	*/
	
	public static void findDuplicateinMapusingIterator() {
		
		
		int tempCount = 0 ;


		Iterator<Map.Entry<Integer,Integer>> iterateMap  = egMap.entrySet().iterator();


		while(iterateMap.hasNext()){

			//iterateMap.next().getKey();
			//iterateMap.next().getValue();


			Iterator<Integer> iterateKeys =  egMap.keySet().iterator();

			
			while(iterateMap.hasNext()){

				if((iterateMap.next().getValue() == egMap.get(iterateKeys.next())) && tempCount < 2) {

					tempCount++;

				}else {
					
					if(tempCount == 2) {
					
					//iterateValues.remove();
					//iterateMap.remove();
					//egMap.remove(iterateKeys.next(),egMap.get(iterateKeys.next()));
					egMap.remove(iterateKeys.next());
					tempCount = 0 ;
					
					}

				}


			}


		}
		
		
		System.out.println(egMap);


	}




	public static void main(String[] args) {

		iterateThruMap.iterateMap(arr);

		//Since the egMap is static during declaration, it can be used in any method without passing it
		iterateThruMap.findDuplicateinMapusingIterator();

	}

}
