package workingWithCollectionsforMap;

import java.util.*;

public class groupStringsByLength {

	public static void main(String[] args) {

		List<String> words = new ArrayList<>();
		words.add("apple");
		words.add("bat");
		words.add("banana");
		words.add("cat");
		words.add("dog");
		
		System.out.println(words);


		// Group the Strings present in List by their unique length
		
		/*
		 * The implementation is as follows::
		 * Iterate the List
		 * Create a tempList 
		 * Create inner List Iteration and add the Strings that are of same size 
		 * Add the Key and same sized String List to the Map
		 * 
		 */

		Map<Integer,List<String>> myMap = new HashMap<>();


		for(int i = 0; i < words.size();i++) {

			List<String> myList = new ArrayList<>();
			
			myList.add(words.get(i));

			for (int j = i+1 ; j < words.size(); j++) {

				if(words.get(i).length() == words.get(j).length()) {

					myList.add(words.get(j));


				}

			}
			
			
			myMap.putIfAbsent(words.get(i).length(), myList);
			
			myList = new ArrayList<>();


		}


		System.out.println(myMap);

	}

}
