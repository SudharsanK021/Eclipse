package workingWithCollectionsforMap;


import java.util.*;

public class countStringFrequencyInSentence {

	public static void main(String[] args) {
		
		// The Logic is simple
		// First split the given sentence using split() method
		// Iterate through the array
		// Check if the value is already present in the Map
		//If yes, just update the Value
		// Else, Store the key and value

		String text = "apple banana apple orange banana apple";

		String [] strArray = text.split(" ");

		Map<String,Integer> myMap = new HashMap<>();

		for (int i = 0; i < strArray.length; i++) {

			if(myMap.get(strArray[i]) != null){

				myMap.put( strArray[i], (myMap.get(strArray[i])+1) );

			}else {
				myMap.put(strArray[i],1);
			}


		}
		
		System.out.println(Arrays.asList(strArray));
		System.out.println(myMap);


	}

}
