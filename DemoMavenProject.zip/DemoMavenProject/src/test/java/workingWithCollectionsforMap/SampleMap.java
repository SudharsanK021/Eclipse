package workingWithCollectionsforMap;

import java.util.*;

public class SampleMap {
	
	
static void usingMapIterator(){
		
		Map<String,String> myMap = new HashMap<String,String>();
			
	  			myMap.put("1","A");
	  			myMap.put("2","B");
	  			myMap.put("3","C");
					
					Iterator<String> iterKeys = myMap.keySet().iterator();
					
					while(iterKeys.hasNext()){
			
								
							System.out.println(myMap.get(iterKeys.next()));
		
						
					}
					
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		usingMapIterator();

	}

}
