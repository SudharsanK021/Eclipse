package workingWithCollectionsforMap;

import java.io.File;
import java.io.FileInputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readObjectRepoFile {

	public static void main(String[] args) throws Exception{
		
		Map<String,String> myMap = new ConcurrentHashMap<>();
		
		String filePath = System.getProperty("user.dir")+"\\src\\test\\java\\workingWithCollectionsforMap\\OR.xlsx";
		//String filePath = "C:\\Users\\sudharsa\\OneDrive - Capgemini\\Documents\\Java BackUp\\LastBackUp\\DemoMavenProject\\src\\test\\java\\workingWithCollectionsforMap\\OR.xlsx";
		
		System.out.println(filePath);
		
		File file = new File(filePath);
		
		FileInputStream inputStream = new FileInputStream(file);
		
		XSSFWorkbook wb = new XSSFWorkbook();
		
		XSSFSheet sheet = wb.getSheetAt(0);
		
		Row row = null;
		
		int rowCount = sheet.getPhysicalNumberOfRows();
		
		for (int i = 0; i < rowCount; i++) {
			
			row = sheet.getRow(i);
			
			for (int j = 0; j < row.getPhysicalNumberOfCells(); j++) {
					
					myMap.put(row.getCell(i).getStringCellValue(), row.getCell(j).getStringCellValue());
				
			}
			
		}
		
		
		System.out.println(myMap);
		
		
		
		

	}

}
